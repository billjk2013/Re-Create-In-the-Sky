//onEvent('recipes', event => {
    ServerEvents.recipes(event => {
        event.shapeless('2x minecraft:coal', [
            'minecraft:charcoal',
            'minecraft:charcoal',
            'minecraft:charcoal',
            'minecraft:charcoal',
        ])
        event.shaped('2x minecraft:red_sand',  [
            'BA',
            'AB',
        ],{
            A: 'minecraft:sand',
            B: 'minecraft:red_dye'
        })
        event.shaped(' easy_villagers:villager',  [
            'ABA',
            'DCE',
            'AFA',
        ],{
            A: 'minecraft:emerald_block',
            B: 'minecraft:wheat',
            C: 'minecraft:golden_carrot',
            D: 'minecraft:carrot',
            E: 'minecraft:beetroot',
            F: 'minecraft:potato'
        })
        event.shaped(' easy_villagers:villager',  [
            'ABA',
            'DCE',
            'AFA',
        ],{
            A: 'minecraft:diamond_block',
            B: 'minecraft:wheat',
            C: 'minecraft:golden_carrot',
            D: 'minecraft:carrot',
            E: 'minecraft:beetroot',
            F: 'minecraft:potato'
        })
        event.shaped(' minecraft:blaze_rod',  [
            ' A ',
            ' A ',
            ' A ',
        ],{
            A: 'minecraft:blaze_powder',
        })
        event.shaped(' minecraft:leather',  [
            'AA',
            'A ',
        ],{
            A: 'minecraft:rotten_flesh',
        })
        event.shaped('4x minecraft:string',  [
            'A',
        ],{
            A: 'minecraft:white_wool',
        })
        event.remove({output: 'clickmachine:auto_clicker'})
      
        event.shaped('clickmachine:auto_clicker',  [
            'AAA',
            'ABA',
            'ACA',
        ],{
            A: '#forge:stone',
            B: 'minecraft:diamond',
            C: 'minecraft:redstone_block'
        })
        event.shaped('clickmachine:auto_clicker',  [
            'AAA',
            'ABA',
            'ACA',
        ],{
            A: '#forge:cobblestone',
            B: 'minecraft:diamond',
            C: 'minecraft:redstone_block'
        })
        event.remove({output: 'exdeorum:fir_sieve'})
      
        event.shaped('exdeorum:fir_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:fir_planks',
            B: 'biomesoplenty:fir_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:redwood_sieve'})
      
        event.shaped('exdeorum:redwood_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:redwood_planks',
            B: 'biomesoplenty:redwood_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:mahogany_sieve'})
              
        event.shaped('exdeorum:mahogany_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:mahogany_planks',
            B: 'biomesoplenty:mahogany_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:jacaranda_sieve'})
              
        event.shaped('exdeorum:jacaranda_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:jacaranda_planks',
            B: 'biomesoplenty:jacaranda_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:palm_sieve'})
              
        event.shaped('exdeorum:palm_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:palm_planks',
            B: 'biomesoplenty:palm_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:willow_sieve'})
              
        event.shaped('exdeorum:willow_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:willow_planks',
            B: 'biomesoplenty:willow_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:hellbark_sieve'})
              
        event.shaped('exdeorum:hellbark_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:hellbark_planks',
            B: 'biomesoplenty:hellbark_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:dead_sieve'})
              
        event.shaped('exdeorum:dead_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:dead_planks',
            B: 'biomesoplenty:dead_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:magic_sieve'})
              
        event.shaped('exdeorum:magic_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:magic_planks',
            B: 'biomesoplenty:magic_slab',
            C: 'minecraft:stick'
        })
        event.remove({output: 'exdeorum:umbran_sieve'})
              
        event.shaped('exdeorum:umbran_sieve',  [
            'A A',
            'ABA',
            'C C',
        ],{
            A: 'biomesoplenty:umbran_planks',
            B: 'biomesoplenty:umbran_slab',
            C: 'minecraft:stick'
        })
    })
 