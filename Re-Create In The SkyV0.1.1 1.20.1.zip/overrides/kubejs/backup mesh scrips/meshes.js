// priority: 0


StartupEvents.registry('item', event => {
	
  event.create('recreateinthesky:diamond_mesh','createsifter:mesh').displayName('Diamond Mesh').parentModel("createsifter:block/meshes/custom_mesh").texture("recreateinthesky:item/diamond_mesh");
	event.create('recreateinthesky:gold_mesh','createsifter:mesh').displayName('Gold Mesh').parentModel("createsifter:block/meshes/custom_mesh").texture("recreateinthesky:item/gold_mesh");
	event.create('recreateinthesky:iron_mesh','createsifter:mesh').displayName('Iron Mesh').parentModel("createsifter:block/meshes/custom_mesh").texture("recreateinthesky:item/iron_mesh");
	event.create('recreateinthesky:netherite_mesh','createsifter:mesh').displayName('Netherite Mesh').parentModel("createsifter:block/meshes/custom_mesh").texture("recreateinthesky:item/netherite_mesh");


})