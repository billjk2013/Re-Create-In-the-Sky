//onEvent('recipes', event => {
    ServerEvents.recipes(event => {
        event.shapeless('2x minecraft:coal', [
            'minecraft:charcoal',
            'minecraft:charcoal',
            'minecraft:charcoal',
            'minecraft:charcoal',
        ])
        event.shaped('2x minecraft:red_sand',  [
            'BA',
            'AB',
        ],{
            A: 'minecraft:sand',
            B: 'minecraft:red_dye'
        })
        event.shaped(' easy_villagers:villager',  [
            'ABA',
            'DCE',
            'AFA',
        ],{
            A: 'minecraft:emerald_block',
            B: 'minecraft:wheat',
            C: 'minecraft:golden_carrot',
            D: 'minecraft:carrot',
            E: 'minecraft:beetroot',
            F: 'minecraft:potato'
        })
        event.shaped(' easy_villagers:villager',  [
            'ABA',
            'DCE',
            'AFA',
        ],{
            A: 'minecraft:diamond_block',
            B: 'minecraft:wheat',
            C: 'minecraft:golden_carrot',
            D: 'minecraft:carrot',
            E: 'minecraft:beetroot',
            F: 'minecraft:potato'
        })
        event.shaped(' minecraft:blaze_rod',  [
            ' A ',
            ' A ',
            ' A ',
        ],{
            A: 'minecraft:blaze_powder',
        })
        event.shaped(' minecraft:leather',  [
            'AA',
            'A ',
        ],{
            A: 'minecraft:rotten_flesh',
        })
        event.shaped('4x minecraft:string',  [
            'A',
        ],{
            A: 'minecraft:white_wool',
        })
        event.remove({output: 'clickmachine:auto_clicker'})
      
        event.shaped('clickmachine:auto_clicker',  [
            'AAA',
            'ABA',
            'ACA',
        ],{
            A: '#forge:stone',
            B: 'minecraft:diamond',
            C: 'minecraft:redstone_block'
        })
        event.shaped('clickmachine:auto_clicker',  [
            'AAA',
            'ABA',
            'ACA',
        ],{
            A: '#forge:cobblestone',
            B: 'minecraft:diamond',
            C: 'minecraft:redstone_block'
        })
    })