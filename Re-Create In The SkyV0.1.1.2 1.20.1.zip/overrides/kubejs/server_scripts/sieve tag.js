   // Listen to item tag event
   ServerEvents.tags('item', event => {
    // Get the #forge:cobblestone tag collection and add Diamond Ore to it
    event.add('exdeorum:sieves', 'exdeorum:umbran_sieve','exdeorum:magic_sieve','exdeorum:dead_sieve','exdeorum:hellbark_sieve','exdeorum:willow_sieve','exdeorum:palm_sieve','exdeorum:jacaranda_sieve','exdeorum:mahogany_sieve','exdeorum:fir_sieve','exdeorum:oak_sieve','exdeorum:dark_oak_sieve','exdeorum:birch_sieve','exdeorum:jungle_sieve','exdeorum:acacia_sieve','exdeorum:mangrove_sieve','exdeorum:cherry_sieve','exdeorum:crimson_sieve','exdeorum:warped_sieve','exdeorum:bamboo_sieve',)
  })